function oN() {
  // alert("ok");

  var img = document.getElementById("img");
  
  img.src = "41774.jpg";

}

function oFF() {
  // alert("ok");

  var img = document.getElementById("img");
  
  img.src = "41741.jpg";

}
